load('s11.txt');
x1 = s11(:,1);
y1 = s11(:,2);
plot(x1,y1);
legend('S11');
xlabel('x')
ylabel('y')